<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany; // Import HasMany

class Project extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'description',
        // Add any other fillable attributes for your Project model
    ];

    /**
     * Get the requirements for the project.
     */
    public function requirements(): HasMany
    {
        return $this->hasMany(Requirement::class);
    }

    // You might have other relationships or methods here
}
