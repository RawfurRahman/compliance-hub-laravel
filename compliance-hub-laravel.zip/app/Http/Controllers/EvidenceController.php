<?php

namespace App\Http\Controllers;

use App\Models\Project;
use App\Models\Requirement;
use App\Models\Evidence;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;

class EvidenceController extends Controller
{
    /**
     * Display the evidence management page for a specific project.
     */
    public function show(Project $project)
    {
        // Eager load requirements and their associated evidence
        $requirements = $project->requirements()->with('evidence')->get();

        return view('evidence.show', compact('project', 'requirements'));
    }

    /**
     * Handle the upload of new evidence for a requirement.
     */
    public function upload(Request $request, Requirement $requirement)
    {
        // Validate the incoming request
        $validator = Validator::make($request->all(), [
            'evidence_file' => 'required|file|max:10240|mimes:pdf,doc,docx,xls,xlsx,jpg,jpeg,png,gif,zip', // Max 10MB, common file types
            'description' => 'nullable|string|max:500',
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $file = $request->file('evidence_file');
        $originalName = $file->getClientOriginalName();
        $path = $file->store('evidence', 'public'); // Store in 'storage/app/public/evidence'

        // Create a public URL for the stored file
        $url = Storage::url($path);

        // Save evidence details to the database
        $evidence = $requirement->evidence()->create([
            'name' => $originalName,
            'path' => $path,
            'url' => $url,
            'description' => $request->input('description'),
        ]);

        return back()->with('success', 'Evidence uploaded successfully!');
    }

    /**
     * Remove the specified evidence from storage.
     */
    public function destroy(Evidence $evidence)
    {
        try {
            // Delete the file from storage
            Storage::disk('public')->delete($evidence->path);

            // Delete the record from the database
            $evidence->delete();

            return back()->with('success', 'Evidence deleted successfully!');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to delete evidence: ' . $e->getMessage());
        }
    }
}
