<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('project_pci_dss_details', function (Blueprint $table) {
            $table->json('assessment_activities')->nullable()->after('subcontractor_list');
            $table->json('overall_findings')->nullable()->after('assessment_activities');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('project_pci_dss_details', function (Blueprint $table) {
            $table->dropColumn('assessment_activities');
            $table->dropColumn('overall_findings');
        });
    }
};
