
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'fields', 'type']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'fields', 'type']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div x-data="{ items: [] }" class="bg-white shadow rounded-lg p-6 mb-8">
    <h2 class="text-xl font-semibold text-gray-800 mb-4"><?php echo e($title); ?></h2>

    <template x-for="(item, index) in items" :key="index">
        <div class="border p-4 rounded-lg mb-4">
            <h3 class="font-medium text-gray-700 mb-2"><?php echo e(substr($title, 0, -1)); ?> <span x-text="index + 1"></span></h3>
            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-4">
                    <label for="<?php echo e($type); ?>_<span x-text="index"></span>_<?php echo e($field['name']); ?>" class="block text-sm font-medium text-gray-700"><?php echo e($field['label']); ?></label>
                    <?php if($field['type'] === 'text'): ?>
                        <input type="text" id="<?php echo e($type); ?>_<span x-text="index"></span>_<?php echo e($field['name']); ?>" name="<?php echo e($type); ?>[]['<?php echo e($field['name']); ?>']" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    <?php elseif($field['type'] === 'textarea'): ?>
                        <textarea id="<?php echo e($type); ?>_<span x-text="index"></span>_<?php echo e($field['name']); ?>" name="<?php echo e($type); ?>[]['<?php echo e($field['name']); ?>']" rows="3" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button @click="items.splice(index, 1)" type="button" class="text-red-600 hover:text-red-900 text-sm">Remove</button>
        </div>
    </template>

    <button @click="items.push({})" type="button" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
        Add <?php echo e(substr($title, 0, -1)); ?>

    </button>
</div>
<?php /**PATH H:\VM Backup\compliance-hub-laravel\resources\views/components/dynamic-input-form.blade.php ENDPATH**/ ?>