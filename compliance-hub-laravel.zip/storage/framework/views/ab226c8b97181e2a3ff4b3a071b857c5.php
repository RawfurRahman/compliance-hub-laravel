<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-slate-800">Compliance Dashboard</h1>
            <p class="mt-1 text-md text-slate-500">Overview of your compliance activities and projects</p>
        </div>
    </div>

    <!-- Welcome Message -->
    <div class="bg-white shadow-sm rounded-lg p-6 mb-8 border border-slate-200">
        <h2 class="text-xl font-semibold text-slate-800 mb-2">Welcome, <?php echo e(auth()->user()->username); ?>!</h2>
        <p class="text-slate-600">Your role is: <strong><?php echo e(auth()->user()->roles->first()->name ?? 'Not Assigned'); ?></strong></p>
    </div>

    <!-- Quick Actions Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <!-- Projects Card -->
        <a href="<?php echo e(route('projects.index')); ?>" class="block p-6 bg-white rounded-lg shadow-sm hover:shadow-lg transition-shadow border border-slate-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-sky-100 text-sky-600">
                    <i class="fas fa-folder-open fa-lg"></i>
                </div>
                <div class="ml-4">
                    <p class="text-xl font-bold text-slate-800">Projects</p>
                    <p class="text-sm text-slate-500">View All Assessments</p>
                </div>
            </div>
        </a>
        
        <!-- User Management Card (Admin Only) -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('is-admin')): ?>
        <a href="<?php echo e(route('users.index')); ?>" class="block p-6 bg-white rounded-lg shadow-sm hover:shadow-lg transition-shadow border border-slate-200">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-indigo-100 text-indigo-600">
                    <i class="fas fa-users-cog fa-lg"></i>
                </div>
                <div class="ml-4">
                    <p class="text-xl font-bold text-slate-800">Users</p>
                    <p class="text-sm text-slate-500">Manage System Users</p>
                </div>
            </div>
        </a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\VM Backup\compliance-hub-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>