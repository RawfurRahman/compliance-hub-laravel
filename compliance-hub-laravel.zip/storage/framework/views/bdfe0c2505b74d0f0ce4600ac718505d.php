<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['details', 'paymentChannels']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['details', 'paymentChannels']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white shadow rounded-lg p-6 mb-8">
    <h2 class="text-xl font-semibold text-gray-800 mb-4">Business Overview</h2>

    
    <div class="mb-6">
        <label for="business_overview_desc" class="block text-sm font-medium text-gray-700">Description of Entity's Business</label>
        <div x-show="!isEditing" class="mt-1 p-2 bg-gray-50 rounded-md border"><?php echo e(optional($details)->business_overview_desc ?: 'Not provided.'); ?></div>
        <div x-show="isEditing">
            <textarea name="business_overview_desc" id="business_overview_desc" rows="4" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" x-model="details.business_overview_desc"></textarea>
        </div>
    </div>

    <hr class="my-6">

    
    <div>
        <label class="block text-sm font-medium text-gray-700">Payment Channels</label>
        <div class="mt-2 space-y-2">
            
            <div x-show="isEditing" x-init="if (!Array.isArray(details.payment_channels)) { details.payment_channels = [] }">
                <?php $__currentLoopData = $paymentChannels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex items-center">
                    <input id="channel_<?php echo e(Str::slug($channel)); ?>" name="payment_channels[]" type="checkbox" value="<?php echo e($channel); ?>" class="h-4 w-4 text-blue-600 border-gray-300 rounded" x-model="details.payment_channels">
                    <label for="channel_<?php echo e(Str::slug($channel)); ?>" class="ml-3 block text-sm font-medium text-gray-700"><?php echo e($channel); ?></label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <div x-show="!isEditing">
                <?php if(!empty(optional($details)->payment_channels)): ?>
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = optional($details)->payment_channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="font-semibold text-gray-800"><?php echo e($channel); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php else: ?>
                    <p class="text-gray-500">No payment channels selected.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\VM Backup\compliance-hub-laravel\resources\views/components/pci/business-overview.blade.php ENDPATH**/ ?>