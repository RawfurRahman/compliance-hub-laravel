<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['details']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['details']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white shadow rounded-lg p-6 mb-8">
    <h2 class="text-xl font-semibold text-gray-800 mb-4">Date and Timeframe of Assessment</h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <label for="date_of_report" class="block text-sm font-medium text-gray-700">Date of Report</label>
            <div x-show="!isEditing" class="mt-1 font-semibold text-gray-800"><?php echo e(optional($details)->date_of_report ?? 'Not set'); ?></div>
            <div x-show="isEditing">
                <input type="date" name="date_of_report" id="date_of_report" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" x-model="details.date_of_report">
            </div>
        </div>
        <div>
            <label for="date_assessment_ended" class="block text-sm font-medium text-gray-700">Date Assessment Ended</label>
            <div x-show="!isEditing" class="mt-1 font-semibold text-gray-800"><?php echo e(optional($details)->date_assessment_ended ?? 'Not set'); ?></div>
            <div x-show="isEditing">
                <input type="date" name="date_assessment_ended" id="date_assessment_ended" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" x-model="details.date_assessment_ended">
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\VM Backup\compliance-hub-laravel\resources\views/components/pci/assessment-timeframe.blade.php ENDPATH**/ ?>