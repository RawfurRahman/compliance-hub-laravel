

<?php $__env->startSection('content'); ?>
<form 
    action="<?php echo e(optional($project->pciDssDetails)->exists ? route('pci.update', $project) : route('pci.store')); ?>" 
    method="POST" 
    x-data="{ 
        isEditing: <?php echo e(optional($project->pciDssDetails)->exists ? 'false' : 'true'); ?>,
        addMode: <?php echo e(optional($project->pciDssDetails)->exists ? 'false' : 'true'); ?>,
        originalDetails: <?php echo e(json_encode($project->pciDssDetails)); ?>, 
        details: <?php echo e(json_encode($project->pciDssDetails) ?? '{}'); ?>

    }"
>
    <?php echo csrf_field(); ?>
    <input x-if="addMode" type="hidden" name="project_name" value="<?php echo e($project->name); ?>">
    <template x-if="!addMode">
        <?php echo method_field('PUT'); ?>
    </template>

    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
            <h1 class="text-3xl font-bold text-slate-800">PCI DSS v4.0.1 Assessment</h1>
            <p class="mt-1 text-md text-slate-500">Project: <span class="font-semibold text-slate-600"><?php echo e($project->name); ?></span></p>
        </div>
        <div class="flex items-center space-x-2 mt-4 md:mt-0">
            <a href="<?php echo e(route('pci.report', $project)); ?>" target="_blank" class="inline-flex items-center px-4 py-2 bg-white text-slate-700 rounded-md hover:bg-slate-50 font-semibold border border-slate-300 shadow-sm">
                <i class="fas fa-file-alt mr-2"></i>Generate Report
            </a>
            <div x-show="!isEditing && !addMode">
                <button type="button" @click="isEditing = true" class="inline-flex items-center px-4 py-2 bg-sky-500 text-white rounded-md hover:bg-sky-600 font-semibold shadow-sm">
                    <i class="fas fa-pencil-alt mr-2"></i>Edit Details
                </button>
            </div>
            <div x-show="isEditing">
                <button type="button" @click="isEditing = false; addMode = false; details = JSON.parse(JSON.stringify(originalDetails));" class="inline-flex items-center px-4 py-2 bg-white text-slate-700 rounded-md hover:bg-slate-50 font-semibold border border-slate-300 shadow-sm">Cancel</button>
                <button type="submit" class="inline-flex items-center px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 font-semibold shadow-sm" x-text="addMode ? 'Submit Project' : 'Save Changes'"></button>
            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-800 p-4 mb-6 rounded-r-md" role="alert">
            <p class="font-bold">Success</p>
            <p><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>

    <!-- Main Content Layout -->
    <div class="flex flex-col lg:flex-row gap-8">
        <!-- Sticky Navigation -->
        <aside class="lg:w-1/4 xl:w-1/5">
            <div class="sticky top-8">
                <h3 class="text-lg font-semibold text-slate-800 mb-3">Assessment Sections</h3>
                <nav class="space-y-2">
                    <a href="#project-info" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-info-circle fa-fw mr-3 text-slate-500"></i>Project Info</a>
                    <a href="#assessment-timeframe" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-calendar-alt fa-fw mr-3 text-slate-500"></i>Timeframe</a>
                    <a href="#business-overview" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-briefcase fa-fw mr-3 text-slate-500"></i>Business Overview</a>
                    <a href="#scope-of-work" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-tasks fa-fw mr-3 text-slate-500"></i>Scope of Work</a>
                    <a href="#environment-details" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-network-wired fa-fw mr-3 text-slate-500"></i>Environment</a>
                    <a href="#quarterly-scans" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-search fa-fw mr-3 text-slate-500"></i>Quarterly Scans</a>
                    <a href="#overall-findings" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-clipboard-check fa-fw mr-3 text-slate-500"></i>Overall Findings</a>
                    <a href="#requirements-list" class="flex items-center px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-200 rounded-md"><i class="fas fa-list-ol fa-fw mr-3 text-slate-500"></i>Requirements</a>
                </nav>
            </div>
        </aside>

        <!-- Form Sections -->
        <div class="lg:w-3/4 xl:w-4/5 space-y-8">
            <div id="project-info"><?php if (isset($component)) { $__componentOriginalcbab4bc0410370612de11248ef0a62ff = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcbab4bc0410370612de11248ef0a62ff = $attributes; } ?>
<?php $component = App\View\Components\Pci\ProjectInfo::resolve(['project' => $project] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.project-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\ProjectInfo::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcbab4bc0410370612de11248ef0a62ff)): ?>
<?php $attributes = $__attributesOriginalcbab4bc0410370612de11248ef0a62ff; ?>
<?php unset($__attributesOriginalcbab4bc0410370612de11248ef0a62ff); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcbab4bc0410370612de11248ef0a62ff)): ?>
<?php $component = $__componentOriginalcbab4bc0410370612de11248ef0a62ff; ?>
<?php unset($__componentOriginalcbab4bc0410370612de11248ef0a62ff); ?>
<?php endif; ?></div>
            <div id="assessment-timeframe"><?php if (isset($component)) { $__componentOriginal6d95c998c87ad2fe75c300f920ce4b9a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d95c998c87ad2fe75c300f920ce4b9a = $attributes; } ?>
<?php $component = App\View\Components\Pci\AssessmentTimeframe::resolve(['details' => $project->pciDssDetails] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.assessment-timeframe'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\AssessmentTimeframe::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d95c998c87ad2fe75c300f920ce4b9a)): ?>
<?php $attributes = $__attributesOriginal6d95c998c87ad2fe75c300f920ce4b9a; ?>
<?php unset($__attributesOriginal6d95c998c87ad2fe75c300f920ce4b9a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d95c998c87ad2fe75c300f920ce4b9a)): ?>
<?php $component = $__componentOriginal6d95c998c87ad2fe75c300f920ce4b9a; ?>
<?php unset($__componentOriginal6d95c998c87ad2fe75c300f920ce4b9a); ?>
<?php endif; ?></div>
            <div id="business-overview"><?php if (isset($component)) { $__componentOriginal760c7214563177349f263a6f4f4cc4ed = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal760c7214563177349f263a6f4f4cc4ed = $attributes; } ?>
<?php $component = App\View\Components\Pci\BusinessOverview::resolve(['details' => $project->pciDssDetails] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.business-overview'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\BusinessOverview::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['payment-channels' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($paymentChannels)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal760c7214563177349f263a6f4f4cc4ed)): ?>
<?php $attributes = $__attributesOriginal760c7214563177349f263a6f4f4cc4ed; ?>
<?php unset($__attributesOriginal760c7214563177349f263a6f4f4cc4ed); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal760c7214563177349f263a6f4f4cc4ed)): ?>
<?php $component = $__componentOriginal760c7214563177349f263a6f4f4cc4ed; ?>
<?php unset($__componentOriginal760c7214563177349f263a6f4f4cc4ed); ?>
<?php endif; ?></div>
            <div id="scope-of-work"><?php if (isset($component)) { $__componentOriginal72825ee7f87dd9a720c9bb8eac7e50fc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal72825ee7f87dd9a720c9bb8eac7e50fc = $attributes; } ?>
<?php $component = App\View\Components\Pci\ScopeOfWork::resolve(['details' => $project->pciDssDetails] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.scope-of-work'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\ScopeOfWork::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal72825ee7f87dd9a720c9bb8eac7e50fc)): ?>
<?php $attributes = $__attributesOriginal72825ee7f87dd9a720c9bb8eac7e50fc; ?>
<?php unset($__attributesOriginal72825ee7f87dd9a720c9bb8eac7e50fc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal72825ee7f87dd9a720c9bb8eac7e50fc)): ?>
<?php $component = $__componentOriginal72825ee7f87dd9a720c9bb8eac7e50fc; ?>
<?php unset($__componentOriginal72825ee7f87dd9a720c9bb8eac7e50fc); ?>
<?php endif; ?></div>
            <div id="environment-details"><?php if (isset($component)) { $__componentOriginal9ecf01f9e730a6558dcf92ce8523e196 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ecf01f9e730a6558dcf92ce8523e196 = $attributes; } ?>
<?php $component = App\View\Components\Pci\EnvironmentDetails::resolve(['details' => $project->pciDssDetails] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.environment-details'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\EnvironmentDetails::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ecf01f9e730a6558dcf92ce8523e196)): ?>
<?php $attributes = $__attributesOriginal9ecf01f9e730a6558dcf92ce8523e196; ?>
<?php unset($__attributesOriginal9ecf01f9e730a6558dcf92ce8523e196); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ecf01f9e730a6558dcf92ce8523e196)): ?>
<?php $component = $__componentOriginal9ecf01f9e730a6558dcf92ce8523e196; ?>
<?php unset($__componentOriginal9ecf01f9e730a6558dcf92ce8523e196); ?>
<?php endif; ?></div>
            <div id="quarterly-scans"><?php if (isset($component)) { $__componentOriginalc9b2a3e23b6a28aa72abb8604f6007c8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9b2a3e23b6a28aa72abb8604f6007c8 = $attributes; } ?>
<?php $component = App\View\Components\Pci\QuarterlyScans::resolve(['details' => $project->pciDssDetails] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.quarterly-scans'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\QuarterlyScans::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9b2a3e23b6a28aa72abb8604f6007c8)): ?>
<?php $attributes = $__attributesOriginalc9b2a3e23b6a28aa72abb8604f6007c8; ?>
<?php unset($__attributesOriginalc9b2a3e23b6a28aa72abb8604f6007c8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9b2a3e23b6a28aa72abb8604f6007c8)): ?>
<?php $component = $__componentOriginalc9b2a3e23b6a28aa72abb8604f6007c8; ?>
<?php unset($__componentOriginalc9b2a3e23b6a28aa72abb8604f6007c8); ?>
<?php endif; ?></div>
            <div id="overall-findings"><?php if (isset($component)) { $__componentOriginal459513fca4c68b97bbd7343822e1affd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal459513fca4c68b97bbd7343822e1affd = $attributes; } ?>
<?php $component = App\View\Components\Pci\OverallFindings::resolve(['details' => $project->pciDssDetails] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.overall-findings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\OverallFindings::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal459513fca4c68b97bbd7343822e1affd)): ?>
<?php $attributes = $__attributesOriginal459513fca4c68b97bbd7343822e1affd; ?>
<?php unset($__attributesOriginal459513fca4c68b97bbd7343822e1affd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal459513fca4c68b97bbd7343822e1affd)): ?>
<?php $component = $__componentOriginal459513fca4c68b97bbd7343822e1affd; ?>
<?php unset($__componentOriginal459513fca4c68b97bbd7343822e1affd); ?>
<?php endif; ?>
            
            <!-- ** THE FIX IS HERE: Simplified component call ** -->
            <div id="requirements-list">
                <?php if (isset($component)) { $__componentOriginal781c9ce9d888a22d5e06946424a36260 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal781c9ce9d888a22d5e06946424a36260 = $attributes; } ?>
<?php $component = App\View\Components\Pci\RequirementsList::resolve(['details' => $project->pciDssDetails] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pci.requirements-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Pci\RequirementsList::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal781c9ce9d888a22d5e06946424a36260)): ?>
<?php $attributes = $__attributesOriginal781c9ce9d888a22d5e06946424a36260; ?>
<?php unset($__attributesOriginal781c9ce9d888a22d5e06946424a36260); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal781c9ce9d888a22d5e06946424a36260)): ?>
<?php $component = $__componentOriginal781c9ce9d888a22d5e06946424a36260; ?>
<?php unset($__componentOriginal781c9ce9d888a22d5e06946424a36260); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH H:\VM Backup\compliance-hub-laravel\resources\views/pci/show.blade.php ENDPATH**/ ?>