@extends('layouts.app')

@section('content')
<div x-data="evidenceManager()" class="min-h-screen bg-slate-50 p-4 sm:p-6 lg:p-8 font-inter antialiased">
    <!-- Page Header -->
    <div class="mb-8 bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-4xl font-extrabold text-slate-900 leading-tight">Evidence Management</h1>
        <p class="mt-2 text-lg text-slate-600">Project: <span class="font-bold text-indigo-700">{{ $project->name }}</span></p>
        <p class="mt-1 text-md text-slate-500">Manage and upload evidence for your project requirements.</p>
    </div>

    <div class="flex flex-col lg:flex-row gap-8">
        <!-- Left Column: Requirements & Uploads -->
        <div class="lg:w-2/3 space-y-6">
            <h2 class="text-2xl font-bold text-slate-800 mb-4">Project Requirements</h2>
            @foreach($requirements as $req)
            <div class="bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300 ease-in-out hover:shadow-xl" x-data="{ open: false }">
                <button @click="open = !open" class="flex justify-between items-center w-full text-left p-5 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-opacity-50">
                    <span class="text-xl font-semibold text-slate-800 flex-grow">{{ $req->req_num }}: {{ $req->req_description }}</span>
                    <i :class="{'transform rotate-180': open}" class="fas fa-chevron-down text-slate-500 transition-transform duration-300 ml-4"></i>
                </button>
                <div x-show="open" x-transition:enter="transition ease-out duration-300"
                     x-transition:enter-start="opacity-0 -translate-y-4"
                     x-transition:enter-end="opacity-100 translate-y-0"
                     x-transition:leave="transition ease-in duration-200"
                     x-transition:leave-start="opacity-100 translate-y-0"
                     x-transition:leave-end="opacity-0 -translate-y-4"
                     class="p-5 border-t border-slate-200 bg-slate-50">
                    <!-- This is the div that was incomplete. Corrected and closed. -->
                    <p class="text-slate-700 mb-4">
                        <span class="font-medium">Details:</span> {{ $req->long_description ?? 'No detailed description available.' }}
                    </p>

                    <h3 class="text-lg font-semibold text-slate-800 mb-3">Evidence for this Requirement</h3>
                    <!-- Placeholder for existing evidence list -->
                    <div class="bg-white p-4 rounded-lg border border-slate-200 mb-4">
                        <ul class="space-y-2 text-slate-600">
                            {{-- Example: Loop through $req->evidence --}}
                            {{-- Added null coalescing operator to ensure $req->evidence is an array even if null --}}
                            @forelse($req->evidence ?? [] as $evidence)
                                <li class="flex items-center justify-between py-2 px-3 bg-slate-50 rounded-md border border-slate-100">
                                    <span class="font-medium text-indigo-600">{{ $evidence->name }}</span>
                                    <div class="flex items-center space-x-2">
                                        <a href="{{ $evidence->url }}" target="_blank" class="text-blue-500 hover:text-blue-700 transition-colors duration-200">
                                            <i class="fas fa-eye mr-1"></i> View
                                        </a>
                                        <button @click="deleteEvidence({{ $evidence->id }})" class="text-red-500 hover:text-red-700 transition-colors duration-200">
                                            <i class="fas fa-trash-alt mr-1"></i> Delete
                                        </button>
                                    </div>
                                </li>
                            @empty
                                <li class="text-center text-slate-500 py-2">No evidence uploaded yet for this requirement.</li>
                            @endforelse
                        </ul>
                    </div>

                    <h3 class="text-lg font-semibold text-slate-800 mb-3">Upload New Evidence</h3>
                    <!-- Placeholder for an actual file upload form -->
                    <form action="{{ route('evidence.upload', $req->id) }}" method="POST" enctype="multipart/form-data" class="space-y-4 p-4 bg-white rounded-lg border border-slate-200">
                        @csrf
                        <div>
                            <label for="file-{{ $req->id }}" class="block text-sm font-medium text-slate-700 mb-1">Select File</label>
                            <input type="file" name="evidence_file" id="file-{{ $req->id }}" class="block w-full text-sm text-slate-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-full file:border-0
                                file:text-sm file:font-semibold
                                file:bg-indigo-50 file:text-indigo-700
                                hover:file:bg-indigo-100 hover:file:cursor-pointer"/>
                            @error('evidence_file')
                                <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <label for="description-{{ $req->id }}" class="block text-sm font-medium text-slate-700 mb-1">Description (Optional)</label>
                            <textarea name="description" id="description-{{ $req->id }}" rows="2" class="mt-1 block w-full rounded-md border-slate-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2"></textarea>
                        </div>
                        <button type="submit" class="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors duration-200">
                            Upload Evidence
                        </button>
                    </form>
                </div>
            </div>
            @endforeach
        </div>

        <!-- Right Column: Project Summary / Global Actions -->
        <div class="lg:w-1/3 space-y-6">
            <h2 class="text-2xl font-bold text-slate-800 mb-4">Project Summary</h2>
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-xl font-semibold text-slate-800 mb-3">Project Overview</h3>
                <p class="text-slate-700 mb-2"><span class="font-medium">Status:</span> <span class="text-green-600 font-semibold">In Progress</span></p>
                <p class="text-slate-700 mb-2"><span class="font-medium">Total Requirements:</span> {{ count($requirements) }}</p>
                <p class="text-slate-700 mb-4"><span class="font-medium">Evidence Uploaded:</span> X / Y</p> {{-- Replace X/Y with actual counts --}}
                <button class="w-full py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors duration-200">
                    Generate Compliance Report
                </button>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6">
                <h3 class="text-xl font-semibold text-slate-800 mb-3">Recent Activity</h3>
                <ul class="space-y-3 text-sm text-slate-600">
                    <li><span class="font-medium text-indigo-600">User A</span> uploaded "Doc_Final.pdf" for Req 1.1 <span class="text-slate-500 text-xs ml-1">2 hours ago</span></li>
                    <li><span class="font-medium text-indigo-600">User B</span> reviewed Req 2.3 <span class="text-slate-500 text-xs ml-1">yesterday</span></li>
                    <li><span class="font-medium text-indigo-600">User A</span> commented on Req 1.2 <span class="text-slate-500 text-xs ml-1">3 days ago</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>

{{-- Alpine.js evidenceManager() function placeholder --}}
<script>
    function evidenceManager() {
        return {
            // Placeholder for any Alpine.js state or methods related to evidence management
            // e.g., for handling file uploads, deletions, or status updates
            deleteEvidence(evidenceId) {
                // IMPORTANT: Replace confirm() and alert() with custom modal UI in a production environment.
                // These are blocking and not user-friendly in an iframe.
                if (confirm('Are you sure you want to delete this evidence?')) {
                    // In a real application, you would make an AJAX request here
                    // to your Laravel backend to delete the evidence.
                    console.log('Deleting evidence with ID:', evidenceId);
                    // Example: axios.delete(`/api/evidence/${evidenceId}`).then(response => { /* handle success */ }).catch(error => { /* handle error */ });
                    alert('Evidence deletion initiated for ID: ' + evidenceId + '. (This is a placeholder action)');
                }
            }
        }
    }
</script>

{{-- Make sure you have Font Awesome included in your layouts/app.blade.php for icons --}}
{{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" /> --}}
{{-- And Tailwind CSS setup --}}
{{-- <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet"> --}}
{{-- And Alpine.js setup --}}
{{-- <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script> --}}

@endsection
