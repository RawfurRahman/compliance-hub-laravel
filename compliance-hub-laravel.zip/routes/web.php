<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EvidenceController;
use App\Models\Project; // Assuming you have a Project model and a way to get it

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Example: A basic route to show the project list or a single project
// You'll need to adjust this based on how you access your projects
Route::get('/', function () {
    // For demonstration, fetch a dummy project or the first one
    $project = Project::first(); // Or Project::find(1);
    if (!$project) {
        // Handle case where no project exists, perhaps redirect to project creation
        return redirect('/projects/create')->with('info', 'Please create a project first.');
    }
    return redirect()->route('evidence.show', $project);
});


// Evidence Management Routes
Route::prefix('evidence-management')->group(function () {
    // Route to display the evidence page for a specific project
    // Assumes Project model binding. Make sure your route model binding works.
    Route::get('/projects/{project}', [EvidenceController::class, 'show'])->name('evidence.show');

    // Route to handle evidence file uploads
    Route::post('/requirements/{requirement}/upload', [EvidenceController::class, 'upload'])->name('evidence.upload');

    // Route to handle evidence deletion
    // Use a DELETE request for deletion, often via AJAX
    Route::delete('/evidence/{evidence}', [EvidenceController::class, 'destroy'])->name('evidence.delete');
});

// You might also have authentication routes, etc.
// Auth::routes();
